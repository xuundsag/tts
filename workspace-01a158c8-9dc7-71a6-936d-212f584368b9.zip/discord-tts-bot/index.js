import 'dotenv/config'
import { Client, GatewayIntentBits, SlashCommandBuilder } from 'discord.js'
import { joinVoiceChannel } from '@discordjs/voice'
import { getSettings, setSetting } from './lib/settings.js'
import { joinFor, endSession, getSession, queueAudio, updateFace } from './lib/sessions.js'
import { synthesize, cleanText, splitText } from './lib/speech.js'
import { configEmbed, configRows } from './lib/menus.js'

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.MessageContent,
  ],
})

const commands = [
  new SlashCommandBuilder()
    .setName('tts')
    .setDescription('Join my voice channel and read my messages out loud')
    .addStringOption(option =>
      option.setName('text').setDescription('say this right away').setRequired(false)),
  new SlashCommandBuilder().setName('config').setDescription('Open the TTS settings panel'),
  new SlashCommandBuilder().setName('stop').setDescription('Stop talking, leave the channel and restore my profile'),
].map(command => command.toJSON())

const menuKeys = { language: 'language', voice: 'voiceType', accent: 'accent', speed: 'rate', volume: 'volume' }

client.once('ready', async () => {
  console.log(`ready as ${client.user.tag}`)
  await client.application.commands.set(commands)
  if (process.env.GUILD_ID) {
    const guild = await client.guilds.fetch(process.env.GUILD_ID).catch(() => null)
    if (guild) await guild.commands.set(commands)
  }
})

client.on('messageCreate', async (message) => {
  if (message.author.bot || !message.inGuild()) return

  const lower = message.content.toLowerCase()
  if (/^\.tts(\s|$)/.test(lower)) return startSession(message, message.content.slice(4).trim())
  if (/^\.config(\s|$)/.test(lower)) return sendConfig(message)
  if (/^\.(stop|leave|shutup)(\s|$)/.test(lower)) return stopSession(message)

  await followMode(message)
})

client.on('interactionCreate', async (interaction) => {
  if (interaction.isChatInputCommand()) {
    if (interaction.commandName === 'tts') {
      const member = await interaction.guild.members.fetch(interaction.user.id)
      if (!member.voice.channel) {
        return interaction.reply({ content: 'you need to be in a voice channel first', ephemeral: true })
      }
      const session = await joinFor(member)
      const text = interaction.options.getString('text')
      if (text) await speak(text, interaction.guild, session, member)
      return interaction.reply(`joined ${member.voice.channel} — ping me or reply to me and I'll read your messages out loud`)
    }

    if (interaction.commandName === 'config') {
      const settings = getSettings(interaction.guild.id)
      return interaction.reply({ embeds: [configEmbed(settings)], components: configRows(settings) })
    }

    if (interaction.commandName === 'stop') {
      await endSession(interaction.guild)
      return interaction.reply('cya — profile restored')
    }
  }

  if (interaction.isStringSelectMenu() && interaction.customId.startsWith('tts:')) {
    const key = menuKeys[interaction.customId.slice(4)]
    let value = interaction.values[0]
    if (key === 'rate' || key === 'volume') value = parseInt(value, 10)
    const settings = setSetting(interaction.guild.id, key, value)
    await interaction.update({ embeds: [configEmbed(settings)], components: configRows(settings) })
    return interaction.followup({ content: 'settings saved', ephemeral: true }).catch(() => {})
  }
})

client.on('voiceStateUpdate', async (oldState, newState) => {
  const session = getSession(oldState.guild.id)
  if (!session) return

  if (oldState.id === oldState.guild.client.user.id && !newState.channelId) {
    return endSession(oldState.guild)
  }

  if (!session.speakers.has(oldState.id)) return

  if (!newState.channelId) {
    session.speakers.delete(oldState.id)
    if (session.speakers.size === 0) return endSession(oldState.guild)
  } else if (newState.channelId !== session.channelId) {
    session.channelId = newState.channelId
    session.connection = joinVoiceChannelFor(newState.guild, newState.channelId)
    session.connection.subscribe(session.player)
  }
})

async function startSession(message, text) {
  if (!message.member.voice.channel) {
    return message.reply('you need to be in a voice channel first')
  }
  const session = await joinFor(message.member)
  message.reply(`joined ${message.member.voice.channel} — ping me or reply to me and I'll read your messages out loud`)
  if (text) await speak(text, message.guild, session, message.member)
}

async function followMode(message) {
  const session = getSession(message.guild.id)
  if (!session || !session.speakers.has(message.author.id)) return

  const pinged = message.mentions.has(message.client.user.id)
  let repliedToBot = false
  if (message.reference?.messageId) {
    const target = await message.channel.messages.fetch(message.reference.messageId).catch(() => null)
    repliedToBot = target?.author?.id === message.client.user.id
  }
  if (!pinged && !repliedToBot) return

  const text = cleanText(message.content, message.client.user.id)
  if (!text) return

  message.react('🗣️').catch(() => {})
  await speak(text, message.guild, session, message.member)
}

async function speak(text, guild, session, member) {
  const settings = getSettings(guild.id)
  try {
    for (const chunk of splitText(text)) {
      queueAudio(session, await synthesize(chunk, settings))
    }
  } catch (error) {
    console.error('tts failed', error.message)
  }
  updateFace(guild, session, member)
}

async function sendConfig(message) {
  const settings = getSettings(message.guild.id)
  await message.reply({ embeds: [configEmbed(settings)], components: configRows(settings) })
}

async function stopSession(message) {
  await endSession(message.guild)
  await message.reply('cya — profile restored')
}

function joinVoiceChannelFor(guild, channelId) {
  return joinVoiceChannel({
    channelId,
    guildId: guild.id,
    adapterCreator: guild.voiceAdapterCreator,
  })
}

if (!process.env.TOKEN) {
  console.error('put your bot token in a .env file first (see .env.example)')
  process.exit(1)
}

client.login(process.env.TOKEN)
