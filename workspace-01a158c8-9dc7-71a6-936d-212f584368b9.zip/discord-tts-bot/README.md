# Discord TTS Bot

A text-to-speech bot that joins your voice channel, puts on your server profile
(avatar + nickname) and reads your messages out loud.

## What it does

- `.tts` or `/tts` — joins your voice channel. The bot takes on your guild profile:
  its server avatar becomes yours and its nickname becomes `[ TTS ] <your display name>`.
  Add text after the command (`.tts hello there`) and it speaks that straight away.
- While a session is live, every message you send that **pings the bot** or **replies to
  one of its messages** gets read out in the voice channel. The bot reacts with 🗣️
  instead of replying.
- `.config` or `/config` — a message with dropdown menus for language, voice type,
  accent, speed and volume. Settings are saved per server.
- Auto language detection (franc) — write in another language and the voice switches.
- Accent auto-adapt — English messages can be spoken with an American, British,
  Australian, Indian or Canadian accent; other languages fall back to their natural voice.
- Neural voices via Microsoft Edge TTS (no API key needed), rate and volume control.
- `.stop` / `.leave` / `/stop` — bot leaves, restores its previous server profile.
- Follows you if you switch voice channels. Session ends when the last speaker disconnects.

## Setup

1. Node 18 or newer.
2. `npm install`
3. Copy `.env.example` to `.env` and fill in your bot token. Optionally set `GUILD_ID`
   for instant slash command registration in one server (global commands can take up to
   an hour to appear).
4. In the Discord Developer Portal enable **Message Content Intent** and **Server Members Intent**.
5. Invite the bot with these permissions: View Channels, Send Messages, Read Message History,
   Add Reactions, Use Slash Commands, Connect, Speak, Change Nickname.
6. `npm start`

## How the profile swap works

Discord's per-server profile feature for bots (September 2025) lets bots set a guild
avatar, nickname, banner and bio through `PATCH /guilds/{guild.id}/members/@me`.
The bot backs up its own server profile when a session starts, wears yours during it,
and restores its original profile when the session ends.

## Files

- `index.js` — client, commands, message and voice event wiring
- `lib/sessions.js` — voice sessions, audio queue, profile swap and restore
- `lib/speech.js` — language detection, voice/accent picking, synthesis
- `lib/menus.js` — the `.config` dropdown panel
- `lib/settings.js` — per-guild settings saved to `data/settings.json`
